SELECT * FROM emails;

INSERT INTO emails (email_address, created_at, updated_at) 
             VALUES ("yoyo@girlshavingfun.com", NOW(), NOW());