
from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
app = Flask(__name__)
app.secret_key = "ThisIsSecret!"
mysql = MySQLConnector(app,'mydb')
@app.route('/')
def index():
    #query = "SELECT * FROM emails"
    #email_addresses = mysql.query_db(query)
    return render_template('index.html')

@app.route('/show_emails')
def show_emails():
    query = "SELECT * FROM emails"
    email_addresses = mysql.query_db(query)
    return render_template('show_emails.html', all_emails=email_addresses)

@app.route('/emails/<email_id>')
def show(email_id):
    query = "SELECT * FROM emails WHERE id = :specific_id"
    data = {'specific_id': email_id}
    emails = mysql.query_db(query, data)
    return render_template('index.html', one_email=emails[0])

@app.route('/delete_email/<email_id>', methods=['POST'])
def delete(email_id):
    query = "DELETE FROM emails WHERE id = :id"
    data = {'id': email_id }
    mysql.query_db(query, data)
    return redirect('/show_emails')


@app.route('/emails', methods=['POST'])
def create():
    if len(request.form['email_address']) < 1:
        flash("Email cannot be blank!")
    elif not EMAIL_REGEX.match(request.form['email_address']):
        flash("Invalid Email Address!")
    else:
        flash("The email address entered is valid and was added to our database. Thank you!")

    query = "INSERT INTO emails (email_address, created_at, updated_at) VALUES (:email_address, NOW(), NOW())"

    data = {
                'email_address': request.form['email_address'],
            }

    mysql.query_db(query, data)
    return redirect('/')

app.run(debug=True)
